--Generated) on 09/13/2022 11:12:21 AM  with Version 3.0 of PatchBuilder.
-- MID: 18841; CID: 50300; HTML5 Desktop - Slot - Jade Shuriken V86
USE CASINO
GO
SET NOCOUNT ON
-- Region Check the version information, and that all the dependencies are correct.
IF EXISTS(SELECT 1 FROM tb_CasinoDBVersion WHERE dboObject = 'CasinoCurrentVersion' and Version >= 40000)
BEGIN
PRINT N'INFO: Raptor detected.'
Declare @CasinoDBVersionTable  Table
(
ProcedureName varchar(200),
ProcedureVersion int
)
DECLARE @NL CHAR(1) = char(10);
                DECLARE @Tab CHAR(1) = char(9);
Declare @MistmatchValues varchar(max);
INSERT INTO @CasinoDBVersionTable Values
('dbo.pr_AddFreeGameOffer.PRC',0)
,('dbo.pr_AddFreeGameOfferToGameMap.PRC',2)
,('dbo.pr_AddSlotBettingModel.PRC',9)
,('dbo.pr_AddUserFreeGame.PRC',3)
,('dbo.pr_AuditUserFreeGame.PRC',0)
,('dbo.pr_ChangeLogService_GetRecentEntries.PRC',1)
,('dbo.pr_ChangeLogService_LogActivity.PRC',2)
,('dbo.pr_DeleteFreeGameOfferToGameMap.PRC',1)
,('dbo.pr_FinaliseGame.PRC',1)
,('dbo.pr_GetFreeGameBettingModelAttributeNames.PRC',3)
,('dbo.pr_GetFreeGameDetails.PRC',0)
,('dbo.pr_GetFreeGameSpinInfo.PRC',1)
,('dbo.pr_GetGameSettings.PRC',2)
,('dbo.pr_GetModuleAchievements.PRC',1)
,('dbo.pr_GetUserAchievements.PRC',2)
,('dbo.pr_GetUserFreeGameBettingModels.PRC',1)
,('dbo.pr_GetUserFreeGameOfferInfo.PRC',4)
,('dbo.pr_LogFreeGame.PRC',1)
,('dbo.pr_LogProgressiveWagerContribution.PRC',3)
,('dbo.pr_PlayFreeGame.PRC',5)
,('dbo.pr_PlayGame.PRC',15)
,('dbo.pr_RefreshGame.PRC',8)
,('dbo.pr_SetFreeGameState.PRC',0)
,('dbo.pr_StartFreeGame.PRC',6)
,('dbo.pr_StartGame.PRC',15)
,('dbo.pr_UpdateFreeGameOffer.PRC',2)
,('dbo.pr_UpdateUserFreeGamesLeft.PRC',0)
,('dbo.pr_ViewInstalledGames.PRC',2)
,('dbo.sp_CheckLoggingEnabled.PRC',1)
,('dbo.sp_GetNextRoundNumber.PRC',0)
,('dbo.sp_IntToVarBin.PRC',2)
,('dbo.sp_SetCurrentGame.PRC',9)
,('dbo.sp_UpdateBetInfo.PRC',1)
,('dbo.sp_VarBinToInt.PRC',2)
,('dbo.tb_BetLog.TAB',13)
,('dbo.tb_Betlog_Freegame.TAB',1)
,('dbo.tb_BetLogBetType.TAB',1)
,('dbo.tb_BettingModel.TAB',2)
,('dbo.tb_BettingModelSlot.TAB',1)
,('dbo.tb_BetType.TAB',0)
,('dbo.tb_CreditType.TAB',1)
,('dbo.tb_CurrentGame.TAB',9)
,('dbo.tb_DurationType.TAB',1)
,('dbo.tb_FreeGameOffer.TAB',1)
,('dbo.tb_FreeGameOffer_Duration.TAB',1)
,('dbo.tb_FreeGameOfferToGameMap.TAB',2)
,('dbo.tb_FreeGameSupportedClient.TAB',2)
,('dbo.tb_GameSettings.TAB',11)
,('dbo.tb_InstalledClients.TAB',3)
,('dbo.tb_InstalledGames.TAB',0)
,('dbo.tb_MultiRound.TAB',2)
,('dbo.tb_NextRoundNumber.TAB',1)
,('dbo.tb_Slot_ValidBetLimits.TAB',2)
,('dbo.tb_UserFreeGame.TAB',1)
,('dbo.tb_UserFreeGameAudit.TAB',1)
,('dbo.tb_UserFreeGameState.TAB',1)
,('dbo.tr_SettingsAuditLogInsertGameSettings.TRG',2)
Set @MistmatchValues = 'Procedure and Version Mistmatch Found-' + @NL + (Select STUFF((
Select CONCAT('Procedure:', ct.ProcedureName, @Tab, ' Found Version:', ct.ProcedureVersion, @Tab, ' Expected Version:', cv.Version, @NL)
from @CasinoDBVersionTable ct , tb_CasinoDBVersion cv Where
ct.ProcedureName = cv.dboObject
and cv.Version < ct.ProcedureVersion
for xml path('')),1,0,''));
IF @MistmatchValues IS NOT NULL
  BEGIN
RAISERROR(N'Error: A required dependency checked failed.%s', 15, 1, @MistmatchValues)
END
ELSE
BEGIN
PRINT N'PreInstall Script Run Successfull'
END
END;
 ELSE 
BEGIN
RAISERROR(N'ERROR: Raptor database not found.', 15, 1);
END;
-- EndRegion
SET NOCOUNT OFF
