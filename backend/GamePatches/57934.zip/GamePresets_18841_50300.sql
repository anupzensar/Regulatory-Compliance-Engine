--Generated on 09/13/2022 11:12:23 AM with Version 3.0 of PatchBuilder.
--MID: 18841; CID: 50300; HTML5 Desktop - Slot - Jade Shuriken V86 
USE CASINO;
GO
SET NOCOUNT ON;
--------------------------------------------------------------------------------------------
--WARNING!Only set the following variable to 1 if you are under specific instruction to do so
--and have operator consent to override any default values that they may have applied to the system.
--------------------------------------------------------------------------------------------
DECLARE @ForceUpdate INT;
SET @ForceUpdate = 0;
--------------------------------------------------------------------------------------------
--Region to check tb_ExcludeModule
--------------------------------------------------------------------------------------------
IF EXISTS (SELECT 1 FROM tb_ExcludeModule WHERE ModuleID = 18841)
BEGIN
    RAISERROR(
                 N'ERROR: The module is currently in Tb_ExcludeModule.  Please remove this entry before running this preset and insert the entry back once done.',
                 15,
                 1
             );
    RETURN;
END;
--------------------------------------------------------------------------------------------
--End tb_ExcludeModule Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Start Transaction
--------------------------------------------------------------------------------------------
BEGIN TRANSACTION;
--------------------------------------------------------------------------------------------
--Region Create tb_Module, tb_ModuleTheoretical Information
--------------------------------------------------------------------------------------------
BEGIN TRY
    UPDATE tb_Module
    SET ModuleName = 'Jade Shuriken 86'
    WHERE ModuleID =  18841;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT tb_Module
        (
            ModuleID,
            ModuleName,
            ModuleIP
        )
        VALUES
        ( 18841, 'Jade Shuriken 86', '');
    END;
    --Check tb_ModuleTheoretical
    UPDATE dbo.tb_ModuleTheoretical
    SET Theoretical = dbo.clr_fn_LSR_EncryptData(87)
    WHERE ModuleID = 18841;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT dbo.tb_ModuleTheoretical
        (
            ModuleID,
            Theoretical
        )
        VALUES
        (18841, dbo.clr_fn_LSR_EncryptData(87));
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR:Error in Region Module for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_Module,tb_ModuleTheoretical Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Region Update Game Categories(Game Archiving and Grouping according to revenue stream)
--------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @GameGroupTypeID INT,
            @GameGroupID INT,
            @BasicGameGroupID INT;


    --MGS Archiving Groups 
    SELECT @GameGroupTypeID = GameGroupTypeID
    FROM tb_GameGroupType
    WHERE Description = 'MGS Archiving Groups';

    --Extensible Game
    SELECT @GameGroupID = GameGroupID
    FROM tb_GameGroup
    WHERE Description = 'Extensible Game'
          AND GameGroupTypeID = @GameGroupTypeID;

    DECLARE @GameArchivingGroupDescription NVARCHAR(50);
    SET @GameArchivingGroupDescription = N'MGS Archiving Groups';
    DECLARE @GameArchivingGroupID INT;
    SET @GameArchivingGroupID = @GameGroupID;

    SELECT @BasicGameGroupID = GameGroupID
    FROM tb_BasicGameGroup
    WHERE GameGroupID = @GameGroupID;

    IF (
           @GameGroupTypeID IS NULL
           OR @GameGroupID IS NULL
           OR @BasicGameGroupID IS NULL
       )
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR(N'ERROR: Cound not find Game Group ID or Game Group Type: ''MGS Archiving Groups''', 15, 1);
        RETURN;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM tb_BasicGameGroupMember
        WHERE GameGroupID = @GameGroupID
              AND ModuleID = 18841 )

    BEGIN
        DELETE FROM tb_BasicGameGroupMember
        WHERE ModuleId = 18841 AND GameGroupID <> @GameGroupID AND GameGroupID IN
            (SELECT GameGroupID FROM tb_GameGroup
                WHERE GameGroupTypeID = @GameGroupTypeID)
    END;
    ELSE
    BEGIN
        DELETE FROM tb_BasicGameGroupMember
        WHERE ModuleId = 18841 AND GameGroupID IN
            (SELECT GameGroupID FROM tb_GameGroup
                WHERE GameGroupTypeID = @GameGroupTypeID)
        INSERT tb_BasicGameGroupMember
        (
            GameGroupID,
            ModuleID
        )
        VALUES
        (@GameGroupID, 18841);
    END;

    --Game Category 
    SELECT @GameGroupTypeID = GameGroupTypeID
    FROM tb_GameGroupType
    WHERE Description = 'Game Category';

    --Slots
    SELECT @GameGroupID = GameGroupID
    FROM tb_GameGroup
    WHERE Description = 'Slots'
          AND GameGroupTypeID = @GameGroupTypeID;


    SELECT @BasicGameGroupID = GameGroupID
    FROM tb_BasicGameGroup
    WHERE GameGroupID = @GameGroupID;

    IF (
           @GameGroupTypeID IS NULL
           OR @GameGroupID IS NULL
           OR @BasicGameGroupID IS NULL
       )
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR(N'ERROR: Cound not find Game Group ID or Game Group Type: ''Game Category''', 15, 1);
        RETURN;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM tb_BasicGameGroupMember
        WHERE GameGroupID = @GameGroupID
              AND ModuleID = 18841 )

    BEGIN
        DELETE FROM tb_BasicGameGroupMember
        WHERE ModuleId = 18841 AND GameGroupID <> @GameGroupID AND GameGroupID IN
            (SELECT GameGroupID FROM tb_GameGroup
                WHERE GameGroupTypeID = @GameGroupTypeID)
    END;
    ELSE
    BEGIN
        DELETE FROM tb_BasicGameGroupMember
        WHERE ModuleId = 18841 AND GameGroupID IN
            (SELECT GameGroupID FROM tb_GameGroup
                WHERE GameGroupTypeID = @GameGroupTypeID)
        INSERT tb_BasicGameGroupMember
        (
            GameGroupID,
            ModuleID
        )
        VALUES
        (@GameGroupID, 18841);
    END;

    --Free Game Betting Model 
    SELECT @GameGroupTypeID = GameGroupTypeID
    FROM tb_GameGroupType
    WHERE Description = 'Free Game Betting Model';

    --Slot
    SELECT @GameGroupID = GameGroupID
    FROM tb_GameGroup
    WHERE Description = 'Slot'
          AND GameGroupTypeID = @GameGroupTypeID;


    SELECT @BasicGameGroupID = GameGroupID
    FROM tb_BasicGameGroup
    WHERE GameGroupID = @GameGroupID;

    IF (
           @GameGroupTypeID IS NULL
           OR @GameGroupID IS NULL
           OR @BasicGameGroupID IS NULL
       )
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR(N'ERROR: Cound not find Game Group ID or Game Group Type: ''Free Game Betting Model''', 15, 1);
        RETURN;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM tb_BasicGameGroupMember
        WHERE GameGroupID = @GameGroupID
              AND ModuleID = 18841 )

    BEGIN
        DELETE FROM tb_BasicGameGroupMember
        WHERE ModuleId = 18841 AND GameGroupID <> @GameGroupID AND GameGroupID IN
            (SELECT GameGroupID FROM tb_GameGroup
                WHERE GameGroupTypeID = @GameGroupTypeID)
    END;
    ELSE
    BEGIN
        DELETE FROM tb_BasicGameGroupMember
        WHERE ModuleId = 18841 AND GameGroupID IN
            (SELECT GameGroupID FROM tb_GameGroup
                WHERE GameGroupTypeID = @GameGroupTypeID)
        INSERT tb_BasicGameGroupMember
        (
            GameGroupID,
            ModuleID
        )
        VALUES
        (@GameGroupID, 18841);
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR:Error in  Region Game Categories for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
----End tb_BasicGameGroupMember Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Region Update Default Language Game Name(Friendly Game Name)
--------------------------------------------------------------------------------------------
DECLARE @TranslationStringID INT = NULL;
BEGIN TRY
    UPDATE tb_TranslationContext
    SET IsTranslationUpdatable = 1
    WHERE TranslationContextID = 3;
    EXEC dbo.pr_AddDefaultTranslationString 3,
                                        N'Jade Shuriken',
                                        @TranslationStringID OUTPUT;
    IF NOT EXISTS
    (
        SELECT 1
        FROM tb_TranslatedString
        WHERE TranslationContextID = 3
              AND TranslationStringID = @TranslationStringID
              AND LanguageID = 1
    )
    BEGIN
        EXEC dbo.pr_AddTranslatedString @TranslationStringID, 
                                        3,
                                        1,
                                        N'Jade Shuriken';
    END;
    UPDATE tb_TranslationContext
    SET IsTranslationUpdatable = 0
    WHERE TranslationContextID = 3;

    UPDATE tb_InstalledClients
    SET ClientName = 'HTML5 Desktop - Slot - Jade Shuriken V86',
        ClientTypeID = 70,
        TranslationContextID = 3,
        TranslationStringID = @TranslationStringID
    WHERE ModuleID = 18841
          AND ClientID = 50300;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT tb_InstalledClients
        (
            ModuleID,
            ClientID,
            ClientName,
            TranslationContextID,
            TranslationStringID,
            ClientTypeID
        )
        VALUES
        (18841, 50300, 'HTML5 Desktop - Slot - Jade Shuriken V86', 3, @TranslationStringID, 70);
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in  Region Default Language Game Name for ModuleID 18841, ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_InstalledClients Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Update Common Game Settings
--------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @GameSettings TABLE
    (
        ModuleID INT,
        ClientID INT,
        Name CHAR(50),
        IntValue INT,
        StrValue VARCHAR(255),
        PRIMARY KEY(
                        ModuleID,
                        ClientID,
                        Name
                    )
    );

    INSERT INTO @GameSettings
    VALUES

          (18841, 50300, 'HasBonusFeature', 1, NULL),
          (18841, 50300, 'HasGambleFeature', 0, NULL),
          (18841, 50300, 'HasFreeSpinFeature', 1, NULL),
          (18841, 50300, 'HasNudgeFeature', 0, NULL),
          (18841, 50300, 'IsWayGame', 0, NULL),
          (18841, 50300, 'PaylineCountWithCost', 20, NULL)
    MERGE tb_GameSettings t
    USING @GameSettings s
    ON (
           s.ModuleID = t.ModuleID
           AND s.ClientID = t.ClientID
           AND t.Name = s.Name
       )
    WHEN MATCHED AND s.IntValue IS NULL AND s.StrValue IS NULL THEN
        DELETE
    WHEN MATCHED THEN
        UPDATE SET t.IntValue = s.IntValue,
                   t.StrValue = s.StrValue
    WHEN NOT MATCHED AND (s.IntValue IS NOT NULL OR s.StrValue IS NOT NULL) THEN
        INSERT
        (
            ModuleID,
            ClientID,
            Name,
            IntValue,
            StrValue
        )
        VALUES
        (s.ModuleID, s.ClientID, s.Name, s.IntValue, s.StrValue);
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR:  Error in  Region Common Game Setting  for ModuleID 18841, ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_GameSettings Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Default Module Setting Information Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_BetModel ,tb_BetModelSetting , tb_BetModelGame for  18841,50300,HTML5 Desktop - Slot - Jade Shuriken V86
--------------------------------------------------------------------------------------------
BEGIN TRY
    IF NOT EXISTS (SELECT 1 FROM tb_BetModel WHERE BetModelID = 10)
    BEGIN
        PRINT N'Bet Model does not currently exist, creating...';
        INSERT INTO tb_BetModel
        (
            BetModelID,
            BetModelName
        )
        SELECT 10,
              'BetModel 10';

        INSERT INTO tb_BetModelSetting
        (
            BetModelID,
            SettingID
        )
        VALUES
        --Adding setting 'MaxBet' to the bet model
        (10,105)
        --Adding setting 'MinBet' to the bet model
        ,(10,106)
        --Adding setting 'DefaultChipSize' to the bet model
        ,(10,108)
        --Adding setting 'DefaultNumChips' to the bet model
        ,(10,215)
        --Adding setting 'MaxGambleWin' to the bet model
        ,(10,286)
        --Adding setting 'MaxNumChips' to the bet model
        ,(10,287)
        --Adding setting 'MinNumChips' to the bet model
        ,(10,292)

       IF @@ROWCOUNT <> 7
       BEGIN
           ROLLBACK TRANSACTION;
           RAISERROR(N'ERROR: The Bet Model could not be successfully installed!', 15, 1);
           RETURN;
       END;
       PRINT N'Bet Model created successfully!';
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in Region Bet Model for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
BEGIN TRY
    IF NOT EXISTS (SELECT 1 FROM tb_BetModelGame WHERE ModuleID = 18841)
    BEGIN
        INSERT INTO tb_BetModelGame
        (
           BetModelID,
           ModuleID
        )
        SELECT 10,
               18841; 
    END;
    ELSE
    BEGIN
        IF NOT EXISTS
        (
            SELECT 1
            FROM tb_BetModelGame
            WHERE ModuleID = 18841
                  AND BetModelID = 10
        )
        BEGIN
            -- Move the bet model. We have to do this for all clients.
            DELETE FROM tb_SettingTemplateValue
            WHERE ModuleID = 18841;

            DELETE FROM tb_BetModelGame
            WHERE ModuleID = 18841;

            INSERT INTO tb_BetModelGame
            (
                BetModelID,
                ModuleID
            )
            SELECT 10,
                   18841; 
        END;
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in Region Bet Model for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_BetModel ,tb_BetModelSetting , tb_BetModelGame Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_SettingTemplate for 18841,50300,HTML5 Desktop - Slot - Jade Shuriken V86
--------------------------------------------------------------------------------------------
BEGIN TRY
    DECLARE @SettingTemplate TABLE
    (
        TemplateName VARCHAR(255),
        TemplateID INT NOT NULL PRIMARY KEY
    );
    INSERT INTO @SettingTemplate
    VALUES
    ('Default Settings',0)
    ,('Low Settings',1)
    ,('High Settings',2)
    ,('2 X Multiplier',3)
    ,('5 X Multiplier',4)
    ,('10 X Multiplier',5)
    ,('50 X Multiplier',6)
    ,('100 X Multiplier',7)
    ,('1000 X Multiplier',8)
    ,('25 X Multiplier',9)
    ,('500 X Multiplier',10)
    ,('Bingo',11)
    ,('Wide Settings',12)
    ,('20 x Multiplier',13)
    ,('200 X Multiplier',14)

    MERGE tb_SettingTemplate t
    USING @SettingTemplate s
    ON (s.TemplateID = t.TemplateID)
    WHEN MATCHED THEN
        UPDATE SET t.TemplateName = s.TemplateName
    WHEN NOT MATCHED THEN
        INSERT
        (
            TemplateName,
            TemplateID
        )
        VALUES
        (s.TemplateName, s.TemplateID);
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in  Region Setting Template  for ModuleID 18841, ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_SettingTemplate Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_SettingTemplateValue for 18841, 50300, HTML5 Desktop - Slot - Jade Shuriken V86
--------------------------------------------------------------------------------------------
BEGIN TRY
    DELETE FROM tb_SettingTemplateValue
    WHERE TemplateID IN ( 0,1,2,4,5,6,7,13,14 )
          AND ModuleID = 18841
          AND ClientID = 50300;
    BEGIN
        INSERT INTO tb_SettingTemplateValue
        (
            TemplateID,
            ModuleID,
            ClientID,
            SettingID,
            BetModelID,
            SettingIntValue,
            SettingStringValue
        )
        VALUES
        --TemplateID:-0
        (0,18841,50300,105,10,8000, NULL)
        --TemplateID:-0
        ,(0,18841,50300,106,10,1, NULL)
        --TemplateID:-0
        ,(0,18841,50300,108,10,5, NULL)
        --TemplateID:-0
        ,(0,18841,50300,215,10,40, NULL)
        --TemplateID:-0
        ,(0,18841,50300,286,10,0, NULL)
        --TemplateID:-0
        ,(0,18841,50300,287,10,80, NULL)
        --TemplateID:-0
        ,(0,18841,50300,292,10,1, NULL)
        --TemplateID:-1
        ,(1,18841,50300,105,10,8000, NULL)
        --TemplateID:-1
        ,(1,18841,50300,106,10,1, NULL)
        --TemplateID:-1
        ,(1,18841,50300,108,10,5, NULL)
        --TemplateID:-1
        ,(1,18841,50300,215,10,40, NULL)
        --TemplateID:-1
        ,(1,18841,50300,286,10,0, NULL)
        --TemplateID:-1
        ,(1,18841,50300,287,10,80, NULL)
        --TemplateID:-1
        ,(1,18841,50300,292,10,1, NULL)
        --TemplateID:-2
        ,(2,18841,50300,105,10,8000, NULL)
        --TemplateID:-2
        ,(2,18841,50300,106,10,1, NULL)
        --TemplateID:-2
        ,(2,18841,50300,108,10,5, NULL)
        --TemplateID:-2
        ,(2,18841,50300,215,10,40, NULL)
        --TemplateID:-2
        ,(2,18841,50300,286,10,0, NULL)
        --TemplateID:-2
        ,(2,18841,50300,287,10,80, NULL)
        --TemplateID:-2
        ,(2,18841,50300,292,10,1, NULL)
        --TemplateID:-4
        ,(4,18841,50300,105,10,40000, NULL)
        --TemplateID:-4
        ,(4,18841,50300,106,10,5, NULL)
        --TemplateID:-4
        ,(4,18841,50300,108,10,25, NULL)
        --TemplateID:-4
        ,(4,18841,50300,215,10,40, NULL)
        --TemplateID:-4
        ,(4,18841,50300,286,10,0, NULL)
        --TemplateID:-4
        ,(4,18841,50300,287,10,80, NULL)
        --TemplateID:-4
        ,(4,18841,50300,292,10,1, NULL)
        --TemplateID:-5
        ,(5,18841,50300,105,10,80000, NULL)
        --TemplateID:-5
        ,(5,18841,50300,106,10,10, NULL)
        --TemplateID:-5
        ,(5,18841,50300,108,10,50, NULL)
        --TemplateID:-5
        ,(5,18841,50300,215,10,40, NULL)
        --TemplateID:-5
        ,(5,18841,50300,286,10,0, NULL)
        --TemplateID:-5
        ,(5,18841,50300,287,10,80, NULL)
        --TemplateID:-5
        ,(5,18841,50300,292,10,1, NULL)
        --TemplateID:-6
        ,(6,18841,50300,105,10,400000, NULL)
        --TemplateID:-6
        ,(6,18841,50300,106,10,50, NULL)
        --TemplateID:-6
        ,(6,18841,50300,108,10,200, NULL)
        --TemplateID:-6
        ,(6,18841,50300,215,10,40, NULL)
        --TemplateID:-6
        ,(6,18841,50300,286,10,0, NULL)
        --TemplateID:-6
        ,(6,18841,50300,287,10,80, NULL)
        --TemplateID:-6
        ,(6,18841,50300,292,10,1, NULL)
        --TemplateID:-7
        ,(7,18841,50300,105,10,800000, NULL)
        --TemplateID:-7
        ,(7,18841,50300,106,10,100, NULL)
        --TemplateID:-7
        ,(7,18841,50300,108,10,500, NULL)
        --TemplateID:-7
        ,(7,18841,50300,215,10,40, NULL)
        --TemplateID:-7
        ,(7,18841,50300,286,10,0, NULL)
        --TemplateID:-7
        ,(7,18841,50300,287,10,80, NULL)
        --TemplateID:-7
        ,(7,18841,50300,292,10,1, NULL)
        --TemplateID:-13
        ,(13,18841,50300,105,10,160000, NULL)
        --TemplateID:-13
        ,(13,18841,50300,106,10,20, NULL)
        --TemplateID:-13
        ,(13,18841,50300,108,10,100, NULL)
        --TemplateID:-13
        ,(13,18841,50300,215,10,40, NULL)
        --TemplateID:-13
        ,(13,18841,50300,286,10,0, NULL)
        --TemplateID:-13
        ,(13,18841,50300,287,10,80, NULL)
        --TemplateID:-13
        ,(13,18841,50300,292,10,1, NULL)
        --TemplateID:-14
        ,(14,18841,50300,105,10,800000, NULL)
        --TemplateID:-14
        ,(14,18841,50300,106,10,200, NULL)
        --TemplateID:-14
        ,(14,18841,50300,108,10,1000, NULL)
        --TemplateID:-14
        ,(14,18841,50300,215,10,40, NULL)
        --TemplateID:-14
        ,(14,18841,50300,286,10,0, NULL)
        --TemplateID:-14
        ,(14,18841,50300,287,10,80, NULL)
        --TemplateID:-14
        ,(14,18841,50300,292,10,1, NULL)
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in  Region Setting Template Value  for ModuleID 18841, ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_SettingTemplateValue Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_MGSDefaultModuleSetting for  18841   , 50300, HTML5 Desktop - Slot - Jade Shuriken V86 
--------------------------------------------------------------------------------------------
BEGIN TRY
    --Setting for 'BonusSystem - Wager Contribution Percentage'
    UPDATE tb_MGSDefaultModuleSetting
    SET SettingIntValue = 100,
        SettingStringValue = NULL
    WHERE ModuleID = 18841
          AND ClientID = 0
          AND SettingID = 102;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT INTO tb_MGSDefaultModuleSetting
        (
            ModuleID,
            ClientID,
            SettingID,
            SettingIntValue,
            SettingStringValue
        )
        SELECT 18841,
               0,
               102, 
               100, 
               NULL;
    END;
    --Setting for 'BonusSystem - Adjust Max Bet for Bonus Abuse Protection'
    UPDATE tb_MGSDefaultModuleSetting
    SET SettingIntValue = 1,
        SettingStringValue = NULL
    WHERE ModuleID = 18841
          AND ClientID = 50300
          AND SettingID = 111;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT INTO tb_MGSDefaultModuleSetting
        (
            ModuleID,
            ClientID,
            SettingID,
            SettingIntValue,
            SettingStringValue
        )
        SELECT 18841,
               50300,
               111, 
               1, 
               NULL;
    END;
    --Setting for 'Loyalty System - Wager Contribution Percentage'
    UPDATE tb_MGSDefaultModuleSetting
    SET SettingIntValue = 100,
        SettingStringValue = NULL
    WHERE ModuleID = 18841
          AND ClientID = 0
          AND SettingID = 158;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT INTO tb_MGSDefaultModuleSetting
        (
            ModuleID,
            ClientID,
            SettingID,
            SettingIntValue,
            SettingStringValue
        )
        SELECT 18841,
               0,
               158, 
               100, 
               NULL;
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in  Region MSGDefaultSettings for ModuleID 18841 ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_MGSDefaultModuleSetting Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install PGSI and MGS Default Setting Region
--------------------------------------------------------------------------------------------
BEGIN TRY
    --Now that the template values have been installed, apply the default template
    EXEC pr_ApplyTemplateValuesToPGSI 0, 18841, 50300, @ForceUpdate;
    --Apply the settings that do not belong to a Bet Model
    EXEC pr_ApplyMGSDefaultModuleSettings 18841, 50300, @ForceUpdate;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR:Error occured in Region PGSI and MGS Default Setting for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End PGSI and MGS Default Setting Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Default Module Setting Information Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Install tb_ThermometerInfo Setting  Region
--------------------------------------------------------------------------------------------
BEGIN TRY
    UPDATE tb_ThermometerInfo
    SET HeatConstant = 8000,
        BetMultiplier = 16,
        HotPercentage = 0
    WHERE ModuleID = 18841
          AND ClientID = 50300;
    IF @@ROWCOUNT = 0
    BEGIN 
        INSERT tb_ThermometerInfo
        (
            ModuleID,
            ClientID, 
            HeatConstant,
            BetMultiplier,
            HotPercentage
        )
        VALUES
        (18841, 50300, 8000, 16,0);
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in Region Thermometer Setting for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--End tb_ThermometerInfo Setting  Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Module Exclusion Information  Region
--------------------------------------------------------------------------------------------
BEGIN TRY
    IF EXISTS (SELECT ModuleID FROM tb_ExcludeModule WHERE ModuleID = 18841)
    BEGIN
       DELETE FROM tb_ExcludeModule 
       WHERE ModuleID = 18841;
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in Region Exclude Module for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--END Module Exclusion Information  Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Free Game Support Information Region
--------------------------------------------------------------------------------------------
BEGIN TRY
    UPDATE tb_FreeGameSupportedClient
    SET IsSupported = 1,
        IsBetSettingValidated = 0
    WHERE ModuleID = 18841
          AND ClientID = 50300;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT tb_FreeGameSupportedClient
        (
            ModuleID,
            ClientID,
            IsSupported,
            IsBetSettingValidated
        )
        VALUES
        (18841, 50300, 1, 0);
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in Region Free Game Support Client for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--Free Game Support Information End Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Valid Bet Limit Information Region
--------------------------------------------------------------------------------------------
BEGIN TRY
    UPDATE tb_Slot_ValidBetLimits
    SET Coins = 4,
        Paylines = 40,
        ChipSizes = '1,2,5,10,20,25,50,100,200,500,1000,2000,2500,5000,10000',
        SideBet = 0,
        SideBetToNumberLines = 0,
        SideBetToChipsize = 0,
        SideBetToNrcoins = 0,
        BetMultiplier = 0
    WHERE ModuleID = 18841;
    IF @@ROWCOUNT = 0
    BEGIN
        INSERT tb_Slot_ValidBetLimits
        (
            ModuleID,
            Coins,
            Paylines,
            ChipSizes,
            SideBet,
            SideBetToNumberLines,
            SideBetToChipsize,
            SideBetToNrcoins,
            BetMultiplier
        )
        VALUES
        (18841, 4, 40, '1,2,5,10,20,25,50,100,200,500,1000,2000,2500,5000,10000', 0, 0, 0, 0, 0);
    END;
END TRY
BEGIN CATCH
    IF (XACT_STATE()) <> 0
    BEGIN
        PRINT N'The transaction is in an uncommittable state.Rolling back transaction.';
        ROLLBACK TRANSACTION;
    END;
    RAISERROR(N'ERROR: Error in  Region Slot Valid Bet Limits for ModuleID 18841 and ClientID 50300', 15, 1);
    RETURN;
END CATCH;
--------------------------------------------------------------------------------------------
--Valid Bet Limit Information End Region
--------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------
--Validate the Game Installation Region
--------------------------------------------------------------------------------------------
BEGIN
    DECLARE @installationResult INT;
    EXEC @installationResult = pr_ValidateGameInstall 18841, 50300;
    IF (@installationResult <> 0)
    BEGIN
        ROLLBACK TRANSACTION;
        RAISERROR(N'ERROR: Game Installation failed!', 15, 1);
        RETURN;
    END;
END;
--------------------------------------------------------------------------------------------
--End Validate the Game Installation Region
--------------------------------------------------------------------------------------------
COMMIT TRANSACTION;
PRINT N'Game Validation completed successfully!';
SET NOCOUNT OFF;
--------------------------------------------------------------------------------------------
        --Transaction Committed
--------------------------------------------------------------------------------------------
